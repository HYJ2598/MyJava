localStorage.setItem("host","http://localhost:8080/")
var host = "http://localhost:8080/"