package yjs.tyust.edu.cn.jiewei.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author 徐超
 * @since 2019-07-01
 */
@Controller
@RequestMapping("/testname")
public class TestnameController {

}
