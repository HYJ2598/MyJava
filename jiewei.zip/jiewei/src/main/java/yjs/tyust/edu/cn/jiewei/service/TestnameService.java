package yjs.tyust.edu.cn.jiewei.service;

import yjs.tyust.edu.cn.jiewei.entity.Testname;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author 徐超
 * @since 2019-07-01
 */
public interface TestnameService extends IService<Testname> {

}
