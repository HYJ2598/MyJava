package yjs.tyust.edu.cn.jiewei.service;


import com.baomidou.mybatisplus.extension.service.IService;
import yjs.tyust.edu.cn.jiewei.entity.Admin;

/**
 * <p>
 * 管理员表 服务类
 * </p>
 *
 * @author woyuno
 * @since 2019-05-31
 */
public interface AdminService extends IService<Admin> {

}
