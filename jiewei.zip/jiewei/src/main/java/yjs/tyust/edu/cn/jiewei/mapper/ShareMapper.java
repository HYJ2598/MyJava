package yjs.tyust.edu.cn.jiewei.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import yjs.tyust.edu.cn.jiewei.entity.Share;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author 徐超
 * @since 2019-06-23
 */
public interface ShareMapper extends BaseMapper<Share> {

}
