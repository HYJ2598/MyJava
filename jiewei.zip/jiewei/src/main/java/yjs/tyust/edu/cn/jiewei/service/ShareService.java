package yjs.tyust.edu.cn.jiewei.service;

import com.baomidou.mybatisplus.extension.service.IService;
import yjs.tyust.edu.cn.jiewei.entity.Share;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author 徐超
 * @since 2019-06-23
 */
public interface ShareService extends IService<Share> {

}
