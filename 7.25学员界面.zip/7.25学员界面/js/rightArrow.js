
/*
var num=1;
$('#year_2018').click(function(){
    if(num==1){
        document.getElementById("year_2018").style.background="blue";
        num=0;
    }else{
        document.getElementById("year_2018").style.background="red";
        num=1;
    }
});

*/
